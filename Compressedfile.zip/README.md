# Easy Money Lending — HR & Document Portal

Internal web app for employee records, salary slips, and HR letters.

## Included
- Admin login
- Employee database (SQLite)
- Add/edit employee records
- Payslip generator with earnings/deductions
- Offer, experience and relieving letter generator
- PDF generation with the supplied Easy Money Lending logo
- Email delivery through SMTP
- Responsive mobile-friendly UI

## Run locally
1. Install Node.js 18+.
2. Copy `.env.example` to `.env` and change the admin credentials and SMTP settings.
3. In this folder run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

Default development login if you do not set `.env`: `admin@localhost` / `admin123`. Change it before real use.

## Email
SMTP must be configured in `.env`. For Gmail/Google Workspace, use an App Password or an approved SMTP relay rather than storing your normal account password.

## Production notes
Put the app behind HTTPS, use a strong SESSION_SECRET, back up `data/hr.db`, restrict the admin account, and configure an authenticated SMTP service. The portal is intended for legitimate company HR/payroll administration; verify every document before sending.
