require('dotenv').config();
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const nodemailer = require('nodemailer');
const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const db = new Database(path.join(ROOT, 'data', 'hr.db'));

app.use(express.json({limit:'2mb'}));
app.use(express.urlencoded({extended:true}));
app.use(session({
  secret: process.env.SESSION_SECRET || 'dev-only-change-me',
  resave:false,
  saveUninitialized:false,
  cookie:{httpOnly:true, sameSite:'lax'}
}));
app.use(express.static(path.join(ROOT,'public')));

function initDb(){
  db.exec(`CREATE TABLE IF NOT EXISTS employees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_code TEXT UNIQUE,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    department TEXT,
    designation TEXT,
    joining_date TEXT,
    bank_account TEXT,
    bank_name TEXT,
    ifsc TEXT,
    pan TEXT,
    address TEXT,
    status TEXT DEFAULT 'Active',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER,
    type TEXT NOT NULL,
    period TEXT,
    payload TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(employee_id) REFERENCES employees(id)
  );`);
}
initDb();

function auth(req,res,next){ if(req.session.user) return next(); return res.status(401).json({error:'Unauthorized'}); }
function company(){ return {name:'Easy Money Lending', owner:'Akash Panday', tagline:'Loan Consolidation & Lending Solutions'}; }
function clean(v){ return String(v ?? '').trim(); }
function money(n){ return '₹' + Number(n||0).toLocaleString('en-IN',{minimumFractionDigits:0,maximumFractionDigits:2}); }
function total(obj){ return Object.values(obj||{}).reduce((a,b)=>a+(Number(b)||0),0); }

app.post('/api/login',(req,res)=>{
  const email=clean(req.body.email), password=clean(req.body.password);
  const expectedEmail=process.env.ADMIN_EMAIL || 'admin@localhost';
  const expectedPassword=process.env.ADMIN_PASSWORD || 'admin123';
  if(email===expectedEmail && password===expectedPassword){ req.session.user={email}; return res.json({ok:true}); }
  return res.status(401).json({error:'Invalid login'});
});
app.post('/api/logout',(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/me',(req,res)=>res.json({loggedIn:!!req.session.user, user:req.session.user||null, company:company()}));

app.get('/api/employees',auth,(req,res)=>res.json(db.prepare('SELECT * FROM employees ORDER BY id DESC').all()));
app.get('/api/employees/:id',auth,(req,res)=>{
  const e=db.prepare('SELECT * FROM employees WHERE id=?').get(req.params.id);
  if(!e) return res.status(404).json({error:'Employee not found'});
  res.json(e);
});
app.post('/api/employees',auth,(req,res)=>{
  const d=req.body;
  if(!clean(d.name)) return res.status(400).json({error:'Employee name is required'});
  try{
    const info=db.prepare(`INSERT INTO employees(employee_code,name,email,phone,department,designation,joining_date,bank_account,bank_name,ifsc,pan,address,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      clean(d.employee_code),clean(d.name),clean(d.email),clean(d.phone),clean(d.department),clean(d.designation),clean(d.joining_date),clean(d.bank_account),clean(d.bank_name),clean(d.ifsc),clean(d.pan),clean(d.address),clean(d.status)||'Active');
    res.json({id:info.lastInsertRowid});
  }catch(e){res.status(400).json({error:e.message.includes('UNIQUE')?'Employee ID already exists':e.message});}
});
app.put('/api/employees/:id',auth,(req,res)=>{
  const d=req.body;
  try{
    db.prepare(`UPDATE employees SET employee_code=?,name=?,email=?,phone=?,department=?,designation=?,joining_date=?,bank_account=?,bank_name=?,ifsc=?,pan=?,address=?,status=? WHERE id=?`).run(
      clean(d.employee_code),clean(d.name),clean(d.email),clean(d.phone),clean(d.department),clean(d.designation),clean(d.joining_date),clean(d.bank_account),clean(d.bank_name),clean(d.ifsc),clean(d.pan),clean(d.address),clean(d.status)||'Active',req.params.id);
    res.json({ok:true});
  }catch(e){res.status(400).json({error:e.message});}
});
app.delete('/api/employees/:id',auth,(req,res)=>{ db.prepare('DELETE FROM employees WHERE id=?').run(req.params.id); res.json({ok:true}); });

function makePDF(type, employee, payload){
  return new Promise((resolve,reject)=>{
    const doc=new PDFDocument({size:'A4',margin:45});
    const chunks=[]; doc.on('data',c=>chunks.push(c)); doc.on('end',()=>resolve(Buffer.concat(chunks))); doc.on('error',reject);
    const logo=path.join(ROOT,'public','assets','logo.jpg');
    if(fs.existsSync(logo)) doc.image(logo,45,35,{fit:[95,95]});
    doc.fontSize(21).fillColor('#25366f').font('Helvetica-Bold').text('EASY MONEY',150,48);
    doc.fontSize(18).fillColor('#8dc63f').text('LENDING',150,75);
    doc.fillColor('#222').moveTo(45,115).lineTo(550,115).stroke();
    const title= type==='payslip'?'SALARY SLIP': type==='offer'?'OFFER LETTER': type==='experience'?'EXPERIENCE LETTER':'RELIEVING LETTER';
    doc.fontSize(18).font('Helvetica-Bold').text(title,45,135,{align:'center'});
    doc.moveDown(1);
    doc.font('Helvetica').fontSize(10).fillColor('#222');
    if(type==='payslip'){
      const x=55,y=175; const rows=[['Month',payload.month],['Employee Name',employee.name],['Employee ID',employee.employee_code],['Department',employee.department],['Designation',employee.designation],['Pay Date',payload.payDate||'']];
      rows.forEach((r,i)=>doc.text(r[0],x,y+i*20).text(': '+(r[1]||''),170,y+i*20));
      let yy=310; section(doc,'Earnings',yy); yy+=28; table(doc,['Description','Amount (₹)'],payload.earnings||{},yy); yy+=30+Object.keys(payload.earnings||{}).length*24; doc.font('Helvetica-Bold').text('Total Earnings',370,yy).text(money(total(payload.earnings)),480,yy); yy+=40;
      section(doc,'Deductions',yy); yy+=28; table(doc,['Description','Amount (₹)'],payload.deductions||{},yy); yy+=30+Object.keys(payload.deductions||{}).length*24; doc.font('Helvetica-Bold').text('Total Deductions',370,yy).text(money(total(payload.deductions)),480,yy); yy+=45;
      doc.font('Helvetica-Bold').text('Net Pay',55,yy).text(money(total(payload.earnings)-total(payload.deductions)),170,yy);
      doc.font('Helvetica').text('Bank Account',55,yy+24).text(': '+(employee.bank_account||'Not provided'),170,yy+24);
      doc.text('Payment Mode',55,yy+44).text(': '+(payload.paymentMode||'Bank Transfer'),170,yy+44);
      doc.fontSize(9).fillColor('#666').text('Generated by Easy Money Lending HR Portal',45,790,{align:'center'});
    } else {
      const body=payload.body||'';
      doc.font('Helvetica').fontSize(11).text(`Date: ${payload.date||new Date().toLocaleDateString('en-IN')}`,45,180);
      doc.moveDown();
      doc.font('Helvetica-Bold').fontSize(12).text(`To,\n${employee.name}`);
      doc.moveDown(); doc.font('Helvetica').fontSize(11).text(body,{lineGap:6});
      doc.moveDown(3); doc.font('Helvetica-Bold').text('For Easy Money Lending');
      doc.font('Helvetica').text('Authorized Signatory');
      doc.fontSize(9).fillColor('#777').text('This document is system-generated from company records.',45,790,{align:'center'});
    }
    doc.end();
  });
}
function section(doc,title,y){ doc.font('Helvetica-Bold').fontSize(15).fillColor('#222').text(title,55,y); }
function table(doc,headers,obj,y){
  const x=55,w=480; doc.rect(x,y,w,24).fill('#dce6f7'); doc.fillColor('#222').font('Helvetica-Bold').fontSize(9).text(headers[0],65,y+8).text(headers[1],400,y+8);
  let i=0; Object.entries(obj).forEach(([k,v])=>{const yy=y+24+i*24; doc.rect(x,yy,w,24).stroke('#a8b9d6'); doc.font('Helvetica').text(k,65,yy+8).text(Number(v||0).toLocaleString('en-IN'),410,yy+8); i++;});
}

app.post('/api/documents/payslip/pdf',auth,async(req,res)=>{
  try{
    const employee=db.prepare('SELECT * FROM employees WHERE id=?').get(req.body.employeeId); if(!employee) return res.status(404).json({error:'Employee not found'});
    const payload=req.body.payload||{}; const pdf=await makePDF('payslip',employee,payload);
    db.prepare('INSERT INTO documents(employee_id,type,period,payload) VALUES(?,?,?,?)').run(employee.id,'payslip',payload.month||'',JSON.stringify(payload));
    res.set({'Content-Type':'application/pdf','Content-Disposition':`attachment; filename="${employee.name.replace(/[^a-z0-9]/gi,'_')}_Payslip.pdf"`}).send(pdf);
  }catch(e){res.status(500).json({error:e.message});}
});
app.post('/api/documents/letter/pdf',auth,async(req,res)=>{
  try{
    const employee=db.prepare('SELECT * FROM employees WHERE id=?').get(req.body.employeeId); if(!employee) return res.status(404).json({error:'Employee not found'});
    const type=clean(req.body.type), payload=req.body.payload||{}; if(!['offer','experience','relieving'].includes(type)) return res.status(400).json({error:'Invalid letter type'});
    const pdf=await makePDF(type,employee,payload);
    db.prepare('INSERT INTO documents(employee_id,type,period,payload) VALUES(?,?,?,?)').run(employee.id,type,payload.date||'',JSON.stringify(payload));
    res.set({'Content-Type':'application/pdf','Content-Disposition':`attachment; filename="${employee.name.replace(/[^a-z0-9]/gi,'_')}_${type}.pdf"`}).send(pdf);
  }catch(e){res.status(500).json({error:e.message});}
});

app.post('/api/documents/send-email',auth,async(req,res)=>{
  try{
    const employee=db.prepare('SELECT * FROM employees WHERE id=?').get(req.body.employeeId); if(!employee) return res.status(404).json({error:'Employee not found'});
    if(!employee.email) return res.status(400).json({error:'Employee has no email address'});
    if(!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) return res.status(400).json({error:'SMTP is not configured. Add SMTP settings to .env first.'});
    const transporter=nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:String(process.env.SMTP_SECURE)==='true',auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}});
    const type=clean(req.body.type), payload=req.body.payload||{}; const pdf=await makePDF(type,employee,payload);
    const label=type==='payslip'?'Salary Slip':type==='offer'?'Offer Letter':type==='experience'?'Experience Letter':'Relieving Letter';
    await transporter.sendMail({from:process.env.MAIL_FROM||process.env.SMTP_USER,to:employee.email,subject:`${label} - Easy Money Lending`,text:`Dear ${employee.name},\n\nPlease find your ${label} attached.\n\nRegards,\nEasy Money Lending HR`,attachments:[{filename:`${employee.name.replace(/[^a-z0-9]/gi,'_')}_${type}.pdf`,content:pdf}]});
    res.json({ok:true});
  }catch(e){res.status(500).json({error:e.message});}
});

app.get('*',(req,res)=>res.sendFile(path.join(ROOT,'public','index.html')));
app.listen(PORT,()=>console.log(`Easy Money Lending HR Portal running at http://localhost:${PORT}`));
